//
//  SerialPortDemoController.swift
//  ORSSerialPortSwiftDemo
//
//  Created by DINO EETeam/VN on 07/30/18.
//  Copyright (c) 2014 Open Reel Software. All rights reserved.
//
import Cocoa


class SerialPortDemoController: NSObject, NSApplicationDelegate, ORSSerialPortDelegate, NSUserNotificationCenterDelegate {
	
    @IBOutlet weak var open_close_port: NSButton!
    @IBOutlet var incoming_data: NSTextView!

    @IBOutlet weak var U1_data: NSTextField!
    @IBOutlet weak var U5_length_data: NSTextField!
    @IBOutlet weak var U5_OTP_CODE: NSTextField!
    @IBOutlet weak var U1_data_length: NSTextField!
    @IBOutlet weak var U1_otp_code: NSTextField!
    @IBOutlet weak var status: NSTextField!
    @IBOutlet weak var result_text: NSTextFieldCell!
    
    
    var U5_otp_code: String = ""
    var timer0 = Timer()
    var flag: Bool = false
    var allow: Bool = false
    var u5_done: Bool = false
    var error_time: Int = 1
    let currentTime = Date()
    let format_time = DateFormatter()
    let format_date = DateFormatter()
    

    
    
    
    @IBAction func U1_input(_ sender: NSTextField) {
        print(U1_data.stringValue)
        if allow == true{
        let u1_data: String = U1_data.stringValue
        if u1_data.count == 42{
            U1_data_length.stringValue = String(u1_data.count)
            if u1_data.prefix(9) == "Accessory"{
                flag = true
                let index1 = u1_data.index(u1_data.startIndex, offsetBy: 25)
                let index2 = u1_data.index(u1_data.startIndex, offsetBy: 41)
                U1_otp_code.stringValue = String(u1_data[index1...index2])
            }else {
                if u5_done == true{
                status.stringValue = "U1 data is wrong!"
                flag = false
                U1_otp_code.stringValue = "No data"
               // result_text.stringValue = "NG"
                result_text.textColor = NSColor.red
                clear()
                    }
            }
            if flag == true{
                process()
            }
            
        }else{
            if u5_done == true{
            
            U1_otp_code.stringValue = ""
            print("No U1 input")
            error_time += 1
            print(error_time)
            status.stringValue = "No U1 input!"
            
            if error_time == 5{
            error_time = 0
            result_text.stringValue = "NG"
            result_text.textColor = NSColor.red
                }
            clear()
            
                }
            }
    }
    }
    
    
    @IBAction func Start(_ sender: NSButton) {
        process()
    }
    func process(){
        
        timer0.invalidate()
        timer0 = Timer.scheduledTimer(timeInterval: 0.4, target: self, selector: #selector(Send1), userInfo: nil, repeats: false)
        timer0 = Timer.scheduledTimer(timeInterval: 0.55, target: self, selector: #selector(Send2), userInfo: nil, repeats: false)
        timer0 = Timer.scheduledTimer(timeInterval: 0.8, target: self, selector: #selector(U5_data_process), userInfo: nil, repeats: false)
        
    }
    ///// Func to get the OTP code from U5, output is U5_otp_code
    @objc func U5_data_process(){
        let U5_data: String = incoming_data.string
        let U5_length = U5_data.count
                if U5_length > 200{
                    
                        U5_length_data.stringValue = String(U5_length)
                        let index1 = U5_data.index(U5_data.startIndex, offsetBy: 160)
                        let index2 = U5_data.index(U5_data.startIndex, offsetBy: 176)
                        U5_otp_code = String(U5_data[index1...index2])
                        U5_OTP_CODE.stringValue = String(U5_otp_code)
                        u5_done = true
                        timer0 = Timer.scheduledTimer(timeInterval: 0.5, target: self, selector: #selector(check_code), userInfo: nil, repeats: false)
        }else{
            u5_done = false
            print("Can not read U5 otp!")
            status.stringValue = "Can not read U5 otp!"
            U5_length_data.stringValue = ""
            U5_OTP_CODE.stringValue = ""
            result_text.stringValue = "NG"
            result_text.textColor = NSColor.red
            
                    
        }
    }
    
    ////// check result between U1 and U5 code
    @objc func check_code(){
        
        print("U5 OTP is: \(U5_OTP_CODE.stringValue)")
        print("U1 OTP is: \(U1_otp_code.stringValue)")
        if U5_OTP_CODE.stringValue == U1_otp_code.stringValue{
            print("OTP is matched!")
            status.stringValue = "OTP is matched!"
            result_text.stringValue = "OK"
            result_text.textColor = NSColor.green
            error_time = 0
        }else{
            print("OTP is not matched!")
            status.stringValue = "OTP is not matched!"
            result_text.stringValue = "NG"
            result_text.textColor = NSColor.red
       }
    }
    
    // MARK: -------> Send command:
    
      @objc func Send1() {
        incoming_data.string = ""
        let string1 = "quick_config" + "\r\n"
        let data1 = string1.data(using: String.Encoding.utf8)
        self.serialPort?.send(data1!)
    }
     @objc func Send2() {
        let string2 = "otp asnread 124" + "\r\n"
        let data2 = string2.data(using: String.Encoding.utf8)
        self.serialPort?.send(data2!)
    }
    // Clear the screen
    @IBAction func clear_func(_ sender: NSButton) {
        incoming_data.string = ""
        U1_data.stringValue = ""
        U1_otp_code.stringValue = ""
        U1_data_length.stringValue = ""
        U5_otp_code = ""
        U5_length_data.stringValue = ""
        U5_OTP_CODE.stringValue = ""
        result_text.stringValue = ""
    }
    @objc func clear(){
        incoming_data.string = ""
        U5_otp_code = ""
        U5_length_data.stringValue = ""
        U5_OTP_CODE.stringValue = ""
        
    }
    
    
   
    //MARK:-------------------------------------------------------->SerialPort
    
    
    @objc let serialPortManager = ORSSerialPortManager.shared()
    
    @objc let availableBaudRates = [300, 1200, 2400, 4800, 9600, 14400, 19200, 28800, 38400, 57600, 115200, 230400]
    
    
    @objc dynamic var serialPort: ORSSerialPort? {
        didSet {
            oldValue?.close()
            oldValue?.delegate = nil
            serialPort?.delegate = self
        }
    }

    @IBAction func action_close_open_port(_ sender: NSButton) {
        if let port = self.serialPort{
            if(port.isOpen){
                port.close()
            }else{
                port.open()
            }
        }
    }
	// MARK: - ORSSerialPortDelegate
   @objc func listPort() {
        let availablePorts = ORSSerialPortManager.shared().availablePorts
        var i = 0
        for port in availablePorts {
            print("\(i). \(port.name)")
            i += 1
            
        }
    }
    @IBAction func stop_bit1(_ sender: NSMenuItem) {
        serialPort?.numberOfStopBits = 1
    }
    @IBAction func stop_bit_2(_ sender: NSMenuItem) {
        serialPort?.numberOfStopBits = 2
    }
    
    
       func serialPortWasOpened(_ serialPort: ORSSerialPort) {
        self.open_close_port.title = "Close"
        //serialPort.numberOfDataBits = 8
        serialPort.dtr = true
        serialPort.rts = true
        //serialPort.baudRate = 115200
        //serialPort.numberOfStopBits = 1
        //serialPort.parity = .none
        print("Serial port was opened!")
        status.stringValue = "Serial port was opened!"
        allow = true
        
	}
	
    func serialPortWasClosed(_ serialPort: ORSSerialPort) {
        self.open_close_port.title = "Open"
        print("Serial port was closed!")
        status.stringValue = "Serial port was closed!"
        allow = false
    }
	
	func serialPort(_ serialPort: ORSSerialPort, didReceive data: Data) {
		if let string = NSString(data: data, encoding: String.Encoding.utf8.rawValue) {
            
            self.incoming_data.textStorage?.mutableString.append(string as String)
            self.incoming_data.needsDisplay = true
		}
	}
	
	func serialPortWasRemovedFromSystem(_ serialPort: ORSSerialPort) {
		self.serialPort = nil
        print("Serial port was removed!")
        self.open_close_port.title = "Open"
        status.stringValue = "Serial port was removed!"
	}
	
	func serialPort(_ serialPort: ORSSerialPort, didEncounterError error: Error) {
		print("SerialPort \(serialPort) encountered an error: \(error)")
	}
	
	// MARK: - NSUserNotifcationCenterDelegate
	
	func userNotificationCenter(_ center: NSUserNotificationCenter, didDeliver notification: NSUserNotification) {
		let popTime = DispatchTime.now() + Double(Int64(3.0 * Double(NSEC_PER_SEC))) / Double(NSEC_PER_SEC)
		DispatchQueue.main.asyncAfter(deadline: popTime) { () -> Void in
			center.removeDeliveredNotification(notification)
		}
	}
	
	func userNotificationCenter(_ center: NSUserNotificationCenter, shouldPresent notification: NSUserNotification) -> Bool {
		return true
	}
	
    override init() {
        super.init()

        let nc = NotificationCenter.default
        nc.addObserver(self, selector: #selector(serialPortsWereConnected(_:)), name: NSNotification.Name.ORSSerialPortsWereConnected, object: nil)
        nc.addObserver(self, selector: #selector(serialPortsWereDisconnected(_:)), name: NSNotification.Name.ORSSerialPortsWereDisconnected, object: nil)
        NSUserNotificationCenter.default.delegate = self
    }

    deinit {
        NotificationCenter.default.removeObserver(self)
    }
    
   //  MARK: - Notifications at System
    
    @objc func serialPortsWereConnected(_ notification: Notification) {
        if let userInfo = notification.userInfo {
            let connectedPorts = userInfo[ORSConnectedSerialPortsKey] as! [ORSSerialPort]
            print("Ports were connected: \(connectedPorts)")
            status.stringValue = "Ports were connected: \(connectedPorts)"
        }
    }

    @objc func serialPortsWereDisconnected(_ notification: Notification) {
        if let userInfo = notification.userInfo {
            let disconnectedPorts: [ORSSerialPort] = userInfo[ORSDisconnectedSerialPortsKey] as! [ORSSerialPort]
            print("Ports were disconnected: \(disconnectedPorts)")
            status.stringValue = "Ports were disconn: \(disconnectedPorts)"
        }
    }
    
    
    func applicationDidFinishLaunching(_ aNotification: Notification) {
        
        // Insert code here to initialize your application
        clear()
        
        
    }
    
}
